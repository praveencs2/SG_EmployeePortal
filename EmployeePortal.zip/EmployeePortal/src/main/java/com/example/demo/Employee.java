package com.example.demo;


public class Employee {
	 
    private String firstName;
    private String lastName;
    private String gender;
    private String deteofBirth;
    private String department;
 
    public Employee() {
 
    }
    
    public Employee(String firstName, String lastName, String gender,String deteofBirth,String department) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.deteofBirth = deteofBirth;
        this.department = department;
    }

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDeteofBirth() {
		return deteofBirth;
	}

	public void setDeteofBirth(String deteofBirth) {
		this.deteofBirth = deteofBirth;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}


 
 
}