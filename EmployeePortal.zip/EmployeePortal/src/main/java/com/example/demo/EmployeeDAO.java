package com.example.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDAO {

	private static final Map<String, Employee> empMap = new HashMap<String, Employee>();

	List<Employee> employeeList = new ArrayList<>();

	public List<Employee> getEmployee(String empNo) {
		return employeeList;
	}

	public List<Employee> addEmployee(Employee emp) {
		employeeList.add(emp);
		return employeeList;

	}
/*
	public List<Employee> getAllEmployees() {
		Collection<Employee> c = empMap.values();
		List<Employee> list = new ArrayList<Employee>();
		list.addAll(c);
		return list;
	}*/

}
