import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
import { EmployeeRegistrationService } from '../services/employeeRegistration.service';
import { Employee } from '../model/employee.model';

@Component({
  selector: 'app-employee-portal',
  templateUrl: './employee-portal.component.html',
  styleUrls: ['./employee-portal.component.css']
})
export class EmployeePortalComponent implements OnInit {

  recipeForm:FormGroup

  recipes: Employee[]=[];

  constructor(private employeeRegistrationService: EmployeeRegistrationService) { }

  ngOnInit() {

    let FirstName = '';
    let LastName = '';
    let gender = '';
    let deteofBirth = '';
    let department = '';

    this.recipeForm = new FormGroup({
      'FirstName': new FormControl(FirstName,Validators.required),
      'LastName': new FormControl(LastName,Validators.required),
      'gender': new FormControl(gender,Validators.required),
      'deteofBirth': new FormControl(deteofBirth,Validators.required),
      'department': new FormControl(department,Validators.required)
   })
  }


  addIngredient(){

    let employee = new Employee(this.recipeForm.value['FirstName'],this.recipeForm.value['LastName'],this.recipeForm.value['gender'],this.recipeForm.value['deteofBirth'],this.recipeForm.value['department'])
    console.log("====="+this.recipeForm.value['FirstName'] + "============"+this.recipeForm.value['LastName']);

 

 

          //this.employeeRegistrationService.addEmployee(employee)

           this.employeeRegistrationService.addEmployee(employee)
                       .subscribe(
                           (data:Employee[] )=> {
                            console.log(data)
                       
                            this.recipes = data;
                      
                            },
                           error => console.log("Error :: " + error)
                       )


       

   }
  }