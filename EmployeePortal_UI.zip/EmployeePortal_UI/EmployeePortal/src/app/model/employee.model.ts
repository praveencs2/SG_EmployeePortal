export class Employee {
       public firstName:string;
       public lastName:string;
       public gender:string;
       public deteofBirth:string;
       public department:string;
   
       constructor(firstName:string, lastName:string,gender:string,deteofBirth:string,department:string){
         this.firstName = firstName;
         this.lastName = lastName;
         this.gender = gender;
         this.deteofBirth = deteofBirth;
         this.department = department;
       }

   }