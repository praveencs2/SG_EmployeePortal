
import { Injectable } from '@angular/core';
import { Employee } from '../model/employee.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs'; 

@Injectable()
export class EmployeeRegistrationService{

constructor(private http:HttpClient){}

addEmployee(employee:Employee): Observable<Employee[]> {

    const httpOptions = {
        headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'my-auth-token'
        })
        }; 
               return this.http.post<Employee[]>('http://localhost:9094/employee', employee, httpOptions);
         }

    
}